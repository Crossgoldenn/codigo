"use client";

const TICKER_ITEMS = [
  { symbol: "BTC", label: "Bitcoin" },
  { symbol: "ETH", label: "Ethereum" },
  { symbol: "DOGE", label: "Dogecoin" },
  { symbol: "SOL", label: "Solana" },
  { symbol: "ADA", label: "Cardano" },
  { symbol: "XRP", label: "Ripple" },
  { symbol: "DOT", label: "Polkadot" },
  { symbol: "AVAX", label: "Avalanche" },
  { symbol: "LINK", label: "Chainlink" },
  { symbol: "MATIC", label: "Polygon" },
];

export default function TickerBanner() {
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS]; // duplicate for seamless loop

  return (
    <div
      style={{
        background: "var(--bg-surface)",
        borderBottom: "1px solid var(--border)",
        overflow: "hidden",
        height: 36,
        display: "flex",
        alignItems: "center",
      }}
    >
      <div className="ticker-track">
        {items.map((item, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "0 28px",
              borderRight: "1px solid var(--border)",
              whiteSpace: "nowrap",
            }}
          >
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 11,
                fontWeight: 700,
                color: "var(--accent-btc)",
                letterSpacing: "0.1em",
              }}
            >
              {item.symbol}
            </span>
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 11,
                color: "var(--text-muted)",
              }}
            >
              {item.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
