"use client";

import { useEffect, useState } from "react";
import type { PriceData } from "@/app/page";

const COIN_COLORS: Record<string, string> = {
  bitcoin: "#f4a01c",
  ethereum: "#627eea",
  dogecoin: "#c3a634",
};

interface Props {
  data: PriceData;
  lastFetch: Date | null;
  onRefresh: () => void;
}

function formatUSD(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: n < 1 ? 6 : 2,
    maximumFractionDigits: n < 1 ? 6 : 2,
  }).format(n);
}

function formatMXN(n: number) {
  return new Intl.NumberFormat("es-MX", {
    style: "currency",
    currency: "MXN",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(n);
}

export default function PriceCard({ data, lastFetch, onRefresh }: Props) {
  const [flash, setFlash] = useState(false);
  const color = COIN_COLORS[data.id] || "#f4a01c";
  const isPositive = data.change_24h >= 0;

  useEffect(() => {
    setFlash(true);
    const t = setTimeout(() => setFlash(false), 400);
    return () => clearTimeout(t);
  }, [data.price_usd]);

  return (
    <div
      style={{
        marginTop: 28,
        background: "var(--bg-card)",
        border: `1px solid ${color}30`,
        borderRadius: 12,
        padding: "28px 28px 24px",
        position: "relative",
        overflow: "hidden",
      }}
    >
      {/* Background accent */}
      <div
        style={{
          position: "absolute",
          top: 0,
          right: 0,
          width: 200,
          height: 200,
          background: `radial-gradient(circle at top right, ${color}12, transparent 70%)`,
          pointerEvents: "none",
        }}
      />

      {/* Header row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: 20,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={data.image}
            alt={data.name}
            width={40}
            height={40}
            style={{ borderRadius: "50%" }}
          />
          <div>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontWeight: 700,
                fontSize: 16,
                color: "var(--text-primary)",
              }}
            >
              {data.name}
            </div>
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 12,
                color: "var(--text-muted)",
              }}
            >
              {data.symbol}
            </div>
          </div>
        </div>

        {/* Refresh */}
        <button
          onClick={onRefresh}
          style={{
            background: "transparent",
            border: "1px solid var(--border)",
            borderRadius: 6,
            padding: "6px 12px",
            color: "var(--text-muted)",
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            cursor: "pointer",
            letterSpacing: "0.08em",
            transition: "all 0.15s",
          }}
          onMouseEnter={(e) => {
            (e.target as HTMLButtonElement).style.borderColor = color;
            (e.target as HTMLButtonElement).style.color = color;
          }}
          onMouseLeave={(e) => {
            (e.target as HTMLButtonElement).style.borderColor =
              "var(--border)";
            (e.target as HTMLButtonElement).style.color = "var(--text-muted)";
          }}
        >
          ↻ ACTUALIZAR
        </button>
      </div>

      {/* Main price */}
      <div className={flash ? "flash-in" : ""}>
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: "clamp(28px, 6vw, 52px)",
            fontWeight: 700,
            color: color,
            letterSpacing: "-0.03em",
            lineHeight: 1,
          }}
        >
          {formatUSD(data.price_usd)}
        </div>
        <div
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: 15,
            color: "var(--text-muted)",
            marginTop: 6,
          }}
        >
          {formatMXN(data.price_mxn)}{" "}
          <span style={{ fontSize: 12 }}>MXN</span>
        </div>
      </div>

      {/* Change badges */}
      <div style={{ display: "flex", gap: 10, marginTop: 20, flexWrap: "wrap" }}>
        <Badge
          label="24h"
          value={data.change_24h}
          isPositive={data.change_24h >= 0}
        />
        <Badge
          label="7d"
          value={data.change_7d}
          isPositive={data.change_7d >= 0}
        />
      </div>

      {/* Last updated */}
      {lastFetch && (
        <div
          style={{
            marginTop: 20,
            paddingTop: 16,
            borderTop: "1px solid var(--border)",
            fontFamily: "var(--font-mono)",
            fontSize: 11,
            color: "var(--text-muted)",
            display: "flex",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 6,
          }}
        >
          <span>
            Última consulta:{" "}
            {lastFetch.toLocaleTimeString("es-MX", {
              hour: "2-digit",
              minute: "2-digit",
              second: "2-digit",
            })}
          </span>
          <span style={{ opacity: 0.5 }}>
            Fuente: CoinGecko API
          </span>
        </div>
      )}
    </div>
  );
}

function Badge({
  label,
  value,
  isPositive,
}: {
  label: string;
  value: number;
  isPositive: boolean;
}) {
  const color = isPositive ? "#22c55e" : "#ef4444";
  return (
    <div
      style={{
        background: `${color}15`,
        border: `1px solid ${color}30`,
        borderRadius: 6,
        padding: "4px 10px",
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontFamily: "var(--font-mono)",
        fontSize: 12,
      }}
    >
      <span style={{ color: "var(--text-muted)" }}>{label}</span>
      <span style={{ color, fontWeight: 700 }}>
        {isPositive ? "+" : ""}
        {value?.toFixed(2)}%
      </span>
    </div>
  );
}
