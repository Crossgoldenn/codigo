"use client";

import type { PriceData } from "@/app/page";

interface Props {
  data: PriceData;
}

function formatCompact(n: number) {
  if (n >= 1e12) return `$${(n / 1e12).toFixed(2)}T`;
  if (n >= 1e9) return `$${(n / 1e9).toFixed(2)}B`;
  if (n >= 1e6) return `$${(n / 1e6).toFixed(2)}M`;
  return `$${n.toLocaleString()}`;
}

function formatUSD(n: number) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: n < 1 ? 4 : 2,
    maximumFractionDigits: n < 1 ? 4 : 2,
  }).format(n);
}

const STATS = (data: PriceData) => [
  {
    label: "Cap. de mercado",
    value: formatCompact(data.market_cap_usd),
    sublabel: "USD",
  },
  {
    label: "Volumen 24h",
    value: formatCompact(data.volume_24h),
    sublabel: "USD",
  },
  {
    label: "Máximo 24h",
    value: formatUSD(data.high_24h),
    sublabel: "USD",
    positive: true,
  },
  {
    label: "Mínimo 24h",
    value: formatUSD(data.low_24h),
    sublabel: "USD",
    negative: true,
  },
];

export default function StatsGrid({ data }: Props) {
  const stats = STATS(data);

  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(2, 1fr)",
        gap: 10,
        marginTop: 12,
      }}
    >
      {stats.map((s) => (
        <div
          key={s.label}
          style={{
            background: "var(--bg-surface)",
            border: "1px solid var(--border)",
            borderRadius: 10,
            padding: "16px 18px",
          }}
        >
          <div
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: 11,
              color: "var(--text-muted)",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              marginBottom: 8,
            }}
          >
            {s.label}
          </div>
          <div
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "clamp(14px, 3vw, 18px)",
              fontWeight: 700,
              color: s.positive
                ? "#22c55e"
                : s.negative
                ? "#ef4444"
                : "var(--text-primary)",
              letterSpacing: "-0.01em",
            }}
          >
            {s.value}
          </div>
        </div>
      ))}
    </div>
  );
}
