"use client";

import type { CoinId } from "@/app/page";

const COINS: { id: CoinId; label: string; symbol: string; color: string }[] = [
  { id: "bitcoin", label: "Bitcoin", symbol: "BTC", color: "#f4a01c" },
  { id: "ethereum", label: "Ethereum", symbol: "ETH", color: "#627eea" },
  { id: "dogecoin", label: "Dogecoin", symbol: "DOGE", color: "#c3a634" },
];

interface Props {
  selected: CoinId | null;
  loading: boolean;
  onSelect: (coin: CoinId) => void;
}

export default function CoinSelector({ selected, loading, onSelect }: Props) {
  return (
    <div>
      <p
        style={{
          fontFamily: "var(--font-mono)",
          fontSize: 11,
          color: "var(--text-muted)",
          letterSpacing: "0.15em",
          textTransform: "uppercase",
          marginBottom: 16,
        }}
      >
        Seleccionar activo
      </p>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: 12,
        }}
      >
        {COINS.map((coin) => {
          const isActive = selected === coin.id;
          return (
            <button
              key={coin.id}
              onClick={() => !loading && onSelect(coin.id)}
              disabled={loading}
              style={{
                background: isActive ? `${coin.color}18` : "var(--bg-surface)",
                border: `1px solid ${isActive ? coin.color : "var(--border)"}`,
                borderRadius: 10,
                padding: "20px 16px",
                cursor: loading ? "not-allowed" : "pointer",
                transition: "all 0.2s ease",
                textAlign: "left",
                opacity: loading && !isActive ? 0.5 : 1,
                ...(isActive
                  ? {
                      "--glow-color": `${coin.color}50`,
                    }
                  : {}),
              }}
              className={isActive ? "card-active" : ""}
            >
              <div
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: 20,
                  fontWeight: 700,
                  color: coin.color,
                  letterSpacing: "-0.01em",
                }}
              >
                {coin.symbol}
              </div>
              <div
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: 12,
                  color: "var(--text-muted)",
                  marginTop: 4,
                }}
              >
                {coin.label}
              </div>
              {isActive && (
                <div
                  style={{
                    marginTop: 10,
                    width: 24,
                    height: 2,
                    background: coin.color,
                    borderRadius: 2,
                  }}
                />
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}
