"use client";

import { useState, useCallback } from "react";
import TickerBanner from "@/components/TickerBanner";
import CoinSelector from "@/components/CoinSelector";
import PriceCard from "@/components/PriceCard";
import StatsGrid from "@/components/StatsGrid";

export type CoinId = "bitcoin" | "ethereum" | "dogecoin";

export interface PriceData {
  id: string;
  name: string;
  symbol: string;
  price_usd: number;
  price_mxn: number;
  change_24h: number;
  change_7d: number;
  market_cap_usd: number;
  volume_24h: number;
  high_24h: number;
  low_24h: number;
  image: string;
  last_updated: string;
}

export default function Home() {
  const [selectedCoin, setSelectedCoin] = useState<CoinId | null>(null);
  const [priceData, setPriceData] = useState<PriceData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastFetch, setLastFetch] = useState<Date | null>(null);

  const fetchPrice = useCallback(async (coin: CoinId) => {
    setLoading(true);
    setError(null);
    setSelectedCoin(coin);

    try {
      const res = await fetch(`/api/price?coin=${coin}`);
      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Error desconocido");

      setPriceData(data);
      setLastFetch(new Date());
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : "Error de conexión");
      setPriceData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleRefresh = () => {
    if (selectedCoin) fetchPrice(selectedCoin);
  };

  return (
    <div style={{ minHeight: "100vh", background: "var(--bg-deep)" }}>
      {/* Ticker banner */}
      <TickerBanner />

      {/* Header */}
      <header
        style={{
          borderBottom: "1px solid var(--border)",
          padding: "24px 0",
          background: "var(--bg-deep)",
        }}
      >
        <div
          style={{ maxWidth: 900, margin: "0 auto", padding: "0 24px" }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div
              style={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                background: "var(--accent-green)",
                boxShadow: "0 0 6px var(--accent-green)",
              }}
            />
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 11,
                color: "var(--text-muted)",
                letterSpacing: "0.15em",
                textTransform: "uppercase",
              }}
            >
              MERCADO EN VIVO
            </span>
          </div>
          <h1
            style={{
              fontFamily: "var(--font-mono)",
              fontSize: "clamp(22px, 4vw, 36px)",
              fontWeight: 700,
              color: "var(--text-primary)",
              marginTop: 8,
              letterSpacing: "-0.02em",
            }}
          >
            Crypto<span style={{ color: "var(--accent-btc)" }}>Tracker</span>
          </h1>
          <p
            style={{
              color: "var(--text-muted)",
              fontSize: 14,
              marginTop: 4,
            }}
          >
            Precios en tiempo real vía CoinGecko API
          </p>
        </div>
      </header>

      {/* Main content */}
      <main style={{ maxWidth: 900, margin: "0 auto", padding: "40px 24px" }}>
        {/* Coin selector */}
        <CoinSelector
          selected={selectedCoin}
          loading={loading}
          onSelect={fetchPrice}
        />

        {/* Error */}
        {error && (
          <div
            style={{
              marginTop: 24,
              padding: "16px 20px",
              background: "#ef444415",
              border: "1px solid #ef444440",
              borderRadius: 8,
              color: "#ef4444",
              fontFamily: "var(--font-mono)",
              fontSize: 13,
              display: "flex",
              alignItems: "center",
              gap: 10,
            }}
          >
            <span>⚠</span>
            <span>{error}</span>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div
            style={{
              marginTop: 48,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 16,
            }}
          >
            <div className="spinner" />
            <span
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 12,
                color: "var(--text-muted)",
                letterSpacing: "0.1em",
              }}
            >
              CONSULTANDO MERCADO...
            </span>
          </div>
        )}

        {/* Price data */}
        {!loading && priceData && (
          <>
            <PriceCard
              data={priceData}
              lastFetch={lastFetch}
              onRefresh={handleRefresh}
            />
            <StatsGrid data={priceData} />
          </>
        )}

        {/* Empty state */}
        {!loading && !priceData && !error && (
          <div
            style={{
              marginTop: 64,
              textAlign: "center",
              color: "var(--text-muted)",
            }}
          >
            <div
              style={{
                fontFamily: "var(--font-mono)",
                fontSize: 48,
                opacity: 0.15,
                marginBottom: 16,
              }}
            >
              ₿ Ξ Ð
            </div>
            <p style={{ fontSize: 15 }}>
              Selecciona una criptomoneda para consultar su precio
            </p>
            <p
              style={{
                fontSize: 12,
                marginTop: 8,
                fontFamily: "var(--font-mono)",
                opacity: 0.5,
              }}
            >
              Datos actualizados cada 30 segundos desde CoinGecko
            </p>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer
        style={{
          borderTop: "1px solid var(--border)",
          padding: "20px 24px",
          textAlign: "center",
          color: "var(--text-muted)",
          fontSize: 12,
          fontFamily: "var(--font-mono)",
        }}
      >
        Datos proporcionados por{" "}
        <a
          href="https://www.coingecko.com"
          target="_blank"
          rel="noopener noreferrer"
          style={{ color: "var(--accent-btc)", textDecoration: "none" }}
        >
          CoinGecko
        </a>{" "}
        · No es asesoramiento financiero
      </footer>
    </div>
  );
}
