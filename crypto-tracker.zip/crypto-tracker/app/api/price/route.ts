import { NextRequest, NextResponse } from "next/server";

const COIN_IDS: Record<string, string> = {
  bitcoin: "bitcoin",
  ethereum: "ethereum",
  dogecoin: "dogecoin",
};

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const coin = searchParams.get("coin")?.toLowerCase();

  if (!coin || !COIN_IDS[coin]) {
    return NextResponse.json(
      { error: "Moneda inválida. Usa: bitcoin, ethereum o dogecoin" },
      { status: 400 }
    );
  }

  try {
    const res = await fetch(
      `https://api.coingecko.com/api/v3/coins/${COIN_IDS[coin]}?localization=false&tickers=false&market_data=true&community_data=false&developer_data=false`,
      {
        headers: { Accept: "application/json" },
        next: { revalidate: 30 }, // cache 30s
      }
    );

    if (!res.ok) {
      throw new Error(`CoinGecko respondió con status ${res.status}`);
    }

    const data = await res.json();
    const market = data.market_data;

    return NextResponse.json({
      id: data.id,
      name: data.name,
      symbol: data.symbol.toUpperCase(),
      price_usd: market.current_price.usd,
      price_mxn: market.current_price.mxn,
      change_24h: market.price_change_percentage_24h,
      change_7d: market.price_change_percentage_7d,
      market_cap_usd: market.market_cap.usd,
      volume_24h: market.total_volume.usd,
      high_24h: market.high_24h.usd,
      low_24h: market.low_24h.usd,
      image: data.image.large,
      last_updated: data.last_updated,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "Error al obtener precio. Intenta de nuevo." },
      { status: 500 }
    );
  }
}
